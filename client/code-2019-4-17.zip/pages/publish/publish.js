Page({
  data: {
    address: '点击选择，要勾选哦~',
    message: '',
    contact: '',
    type: 'buy'
  },

  radioChange(e) {
    this.setData({
      type: e.detail.value
    })
  },

  handleAddressTap() {
    wx.chooseLocation({
      success: (res) => {
        this.setData({
          address: res.address
        })
        this.staticData = {
          latitude: res.latitude,
          longitude: res.longitude
        }
      }
    })
  },

  handleMessageInput(e) {
    this.staticData.message = e.detail.value
  },

  handleContactInput(e) {
    this.staticData.contact = e.detail.value
  },

  handleSubmit() {
    let data = {
      ...this.data,
      ...this.staticData
    }

    wx.request({
      url: 'https://ik9hkddr.qcloud.la/index.php/trade/add_item',
      data,
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'POST',
      success(res) {
        console.log(res.data)
      }
    })
  }
})